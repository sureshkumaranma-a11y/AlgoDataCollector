package com.skdmtraders.algodatacollector;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API_BASE = "http://192.168.1.4:8765";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Spinner index, optionType, timeframe;
    private TextView status, dataView;
    private Button fetchButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("Algo Data Collector");
        title.setTextSize(26);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("NIFTY / SENSEX • API Data Viewer");
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        index = new Spinner(this);
        index.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"NIFTY", "SENSEX"}));
        root.addView(index);

        optionType = new Spinner(this);
        optionType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"CALL", "PUT"}));
        root.addView(optionType);

        timeframe = new Spinner(this);
        timeframe.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 Minute", "5 Minutes", "30 Minutes", "1 Hour", "1 Day"}));
        root.addView(timeframe);

        fetchButton = new Button(this);
        fetchButton.setText("Fetch API Data");
        root.addView(fetchButton);

        status = new TextView(this);
        status.setText("Ready. Connect to the laptop API on the same Wi-Fi.");
        status.setPadding(0, 20, 0, 12);
        root.addView(status);

        ScrollView scroll = new ScrollView(this);
        dataView = new TextView(this);
        dataView.setTextSize(13);
        dataView.setTextColor(Color.DKGRAY);
        dataView.setTextIsSelectable(true);
        scroll.addView(dataView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        fetchButton.setOnClickListener(v -> fetchData());
        setContentView(root);
    }

    private void fetchData() {
        final String symbol = index.getSelectedItem().toString();
        final String option = optionType.getSelectedItem().toString();
        fetchButton.setEnabled(false);
        status.setText("Connecting to API...");
        dataView.setText("");

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String urlText = API_BASE + "/api/data?symbol=" + symbol
                        + "&option_type=" + option + "&limit=10";
                connection = (HttpURLConnection) new URL(urlText).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/json");

                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                }
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + body);

                JSONObject json = new JSONObject(body.toString());
                int count = json.optInt("count", 0);
                JSONArray records = json.optJSONArray("data");
                StringBuilder display = new StringBuilder();
                display.append("Instrument: ").append(symbol).append(" ").append(option)
                        .append("\nRecords received: ").append(count).append("\n\n");

                if (records == null || records.length() == 0) {
                    display.append("No records found for this selection.");
                } else {
                    for (int i = 0; i < records.length(); i++) {
                        JSONObject r = records.getJSONObject(i);
                        display.append("Record ").append(i + 1).append("\n")
                                .append("Time: ").append(r.optString("datetime_ist",
                                        r.optString("timestamp", "N/A"))).append("\n")
                                .append("Open: ").append(r.optString("open", "N/A"))
                                .append("  High: ").append(r.optString("high", "N/A")).append("\n")
                                .append("Low: ").append(r.optString("low", "N/A"))
                                .append("  Close: ").append(r.optString("close", "N/A")).append("\n")
                                .append("Spot: ").append(r.optString("spot", "N/A"))
                                .append("  Strike: ").append(r.optString("strike", "N/A")).append("\n")
                                .append("IV: ").append(r.optString("iv", "N/A"))
                                .append("  Volume: ").append(r.optString("volume", "N/A"))
                                .append("  OI: ").append(r.optString("oi", "N/A")).append("\n\n");
                    }
                }

                final String resultText = display.toString();
                runOnUiThread(() -> {
                    status.setText("API connected. Historical CSV data loaded.");
                    dataView.setText(resultText);
                    fetchButton.setEnabled(true);
                });
            } catch (Exception e) {
                final String message = e.getClass().getSimpleName() + ": " + e.getMessage();
                runOnUiThread(() -> {
                    status.setText("API connection failed. Check laptop server and Wi-Fi.");
                    dataView.setText(message + "\n\nAPI: " + API_BASE);
                    fetchButton.setEnabled(true);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
